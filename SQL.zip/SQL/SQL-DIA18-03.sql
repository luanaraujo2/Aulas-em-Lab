--tabela mostrada + dia da semana e status de "paga" ou "nao paga"

declare @datainicial date
declare @datafinal date

set @datainicial = '01/01/2025'
set @datafinal = '01/01/2026'

select emp_razaosocial,
pag_fatura,
pag_valor,
pag_datavencimento,
pag_datapagto,
	case datepart(dw, pag_datavencimento)
			when 1 then 'domingo'
			when 2 then 'segunda'
			when 3 then'domingo'
			when 4 then 'domingo'
			when 5 then 'domingo'
			when 6 then 'sexta'
			when 7 then 'sabado'
	end as dia,
		case when pag_datapagto is null then 'Em aberto' else 'Ja paga' end as status
from pagar, empresa where fkempresa=idempresa
and pag_datapagto >= @datainicial and pag_datapagto <= @datafinal

--fazer backup por dia da semana
declare @nomeBkp varchar(80)

set @nomeBkp =
	case datepart(dw, getdate()) 
			when 1 then 'domingo'
			when 2 then 'segunda'
			when 3 then'domingo'
			when 4 then 'domingo'
			when 5 then 'domingo'
			when 6 then 'sexta'
			when 7 then 'sabado'
	end

set @nomeBkp = 'C:\DevC\'+@nomeBkp
backup database Uvv to disk = @nomeBkp

--tabela empresa deve receber "nao informado" no campo que se pede, ao enves de null

update empresa 
	set emp_telefone = 'N�o informado'
where emp_telefone is null 
	and idempresa in
	(select distinct fkempresa from pagar) -- 0 linhas afetadas

select emp_telefone from empresa where emp_telefone is null

--tabela temporaria global + copiar tabela s� estrutura
select * into ##pag_temp from pagar

select * into ##pag_temp2 from pagar where 2=3

select * from ##pag_temp2